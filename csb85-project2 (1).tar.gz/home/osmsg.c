#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <linux/kernel.h>
#include <unistd.h>

//wrapper function for send_msg syscall
int send_msg(char *to, char *msg, char *from){
	syscall(441, to, msg, from);
}

//wrapper function for get_msg syscall
int get_msg(char *to, char *msg, long msg_len, char *from, long from_len){
	syscall(442, to, msg, msg_len, from, from_len);
}


int main(int argc, char* argv[]){

	//variable declarations
	int opt_val, sflag = 0, rflag = 0;
	char* to;

	//while loop to check command given by user
	while((opt_val = getopt(argc, argv, "s:r"))!=-1){

		//switch statement to differentiate -s and -r
		switch(opt_val){

			case 's':
				sflag = 1;
				to = optarg;
				break;
			case 'r':
				rflag = 1;
				break;
		}

	}

	//user included -s command
	if(sflag == 1){

		//too many command line arguemnts included
		if(argc > (optind + 1)){
			printf("Too many arguments given");
			return 0;
		}

		//setting msg to last command line argument
		char *msg = argv[optind];

		//calling send_msg syscall and storing the return value
		int res = send_msg(to, msg, getenv("USER"));

		//confirmation that message was sent successfully
		if(res == 0)
			printf("Successfully sent \"%s\" to %s\n", msg, to);
		else
			printf("Message failed to send\n");
	}

	//user indicated -r command
	if(rflag == 1){

		//declaring buffers for get_msg to fill
		char msg[32];
		char from[16];

		//calling get_msg syscall and storing the return value
		int res = get_msg(getenv("USER"), msg, sizeof(msg), from, sizeof(from));

		//error reading messages
		if(res < -1){
			printf("Error reading messages\n");
			return 0;
		}

		//no messages to read
		if(res == -1){
			printf("No messages to read\n");
			return 0;
		}

		//print messages until the last one (ret == 0)
		while(res > 0){
			printf("%s said: \"%s\"\n", from, msg);
			res = get_msg(getenv("USER"), msg, sizeof(msg), from, sizeof(from));
		}

		//print out last message
		printf("%s said: \"%s\"\n", from, msg);

	}

	return 0;
}
